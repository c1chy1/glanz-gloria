self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0298087455485dad829f",
    "url": "/css/about.2c2741c9.css"
  },
  {
    "revision": "3afa9ac1d048039e945a",
    "url": "/css/app.a9258824.css"
  },
  {
    "revision": "2675beb7ba49ed4dc57b",
    "url": "/css/chunk-vendors.61dcfff8.css"
  },
  {
    "revision": "a3e9eb83892b6c2c29a1",
    "url": "/css/contact.75f83177.css"
  },
  {
    "revision": "cc128cc5da8ddfd86402",
    "url": "/css/services.f643be3f.css"
  },
  {
    "revision": "bb8f9b67a69820b1cf8b4f9900b41980",
    "url": "/fonts/AmsiPro-Regular.bb8f9b67.woff2"
  },
  {
    "revision": "5a8b71b551101493533d95d6045cd931",
    "url": "/fonts/Lato-Italic.5a8b71b5.woff2"
  },
  {
    "revision": "15d97d6d809245a7ebadbe405c377a36",
    "url": "/fonts/helvetica-regular.15d97d6d.woff2"
  },
  {
    "revision": "a6f917463b7f5632087179f5044ab397",
    "url": "/fonts/manrope.light.a6f91746.woff2"
  },
  {
    "revision": "ed0b3eb895891462eda34c60a3acdfd1",
    "url": "/img/Google_map.ed0b3eb8.png"
  },
  {
    "revision": "0e2ec85f7bb3a2890050cfe065e753a3",
    "url": "/img/about_img.0e2ec85f.jpg"
  },
  {
    "revision": "e1a1eddcb727c33aa3b4f2d272baf911",
    "url": "/img/contact_header.e1a1eddc.jpg"
  },
  {
    "revision": "7d6991b843a635eee829abdcfbc42be3",
    "url": "/img/home_header.7d6991b8.jpg"
  },
  {
    "revision": "6590ebe5c92f807a6cc3f757e8931188",
    "url": "/img/logo_final.6590ebe5.png"
  },
  {
    "revision": "a42ab3446df118be43a1aeef45b322c5",
    "url": "/img/services_header.a42ab344.jpg"
  },
  {
    "revision": "bc0a7d506f6cf52f57ce3abcb482068b",
    "url": "/img/ueber_header.bc0a7d50.jpg"
  },
  {
    "revision": "3ebb9be3f201bd290e351be7bb5ba1fe",
    "url": "/img/ueber_img.3ebb9be3.jpg"
  },
  {
    "revision": "78abc793c012783a6f4a52693ae91af7",
    "url": "/index.html"
  },
  {
    "revision": "0298087455485dad829f",
    "url": "/js/about.2813cab9.js"
  },
  {
    "revision": "3afa9ac1d048039e945a",
    "url": "/js/app.c630cb56.js"
  },
  {
    "revision": "2675beb7ba49ed4dc57b",
    "url": "/js/chunk-vendors.d2a45b9c.js"
  },
  {
    "revision": "a3e9eb83892b6c2c29a1",
    "url": "/js/contact.88a9d896.js"
  },
  {
    "revision": "685b839c3b5accf49b47",
    "url": "/js/datenschutz.2ead1a41.js"
  },
  {
    "revision": "87b500ced71e6c929210",
    "url": "/js/impressum.1bdfd25d.js"
  },
  {
    "revision": "cc128cc5da8ddfd86402",
    "url": "/js/services.5aaee678.js"
  },
  {
    "revision": "846ed84d1070173e2efc913f71d81717",
    "url": "/manifest.json"
  },
  {
    "revision": "0219f1de0160438878023839136883db",
    "url": "/pwa/logo_192x192.png"
  },
  {
    "revision": "a0d044de745e54e71edc9056ba16ef81",
    "url": "/pwa/logo_192x192.webp"
  },
  {
    "revision": "46cdd812a7b8559aba9d592c94d65692",
    "url": "/pwa/logo_512x512.png"
  },
  {
    "revision": "8c8edaefaeaf202eba0d3c0a1ceafc91",
    "url": "/pwa/logo_512x512.webp"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "57d4de4942cac0f4b89ee548fa6c5284",
    "url": "/sw.js"
  }
]);